#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"	 
#include "rs485.h"
#include "usart3.h"

u8 huo;
u8 ke;
extern u8 finish;
extern u8 flag;
extern float temp;
extern float humi;
extern u16 pm25;
extern u16 co2;
extern u16 tvoc;
extern u8 flag;
extern u8 set_temp;
extern u8 set_humi;
extern u16 set_tvoc;
extern u16 set_co2;
extern u16 set_pm25;
int main(void)
{	 
	u8 key;
	u8 i=0,t=0;
	u8 cnt=0;
	u8 rs485buf[8]={0XFF,0X08,0X00,0X00,0X01,0X00,0XF4,0X45}; 

	delay_init();	    	 //��ʱ������ʼ��	  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����ж����ȼ�����Ϊ��2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(9600);	 	//���ڳ�ʼ��
	usart3_init(9600);
	io();
	LED_Init();		  		//��ʼ����LED���ӵ�Ӳ���ӿ�			 	 
	RS485_Init(9600);	//��ʼ��RS485
	delay_ms(1000);				  
	while(1)
	{
		
		RS485_Send_Data(rs485buf,8);
		if(flag==1 && finish==1)
		{
			if(flame==1)
			{
				printf("shuju.t13.txt=\"��\"\xff\xff\xff");
				printf("shuju.p13.pic=14\xff\xff\xff");
				huo=0;
			}
			else
			{
				printf("shuju.t13.txt=\"��\"\xff\xff\xff");
				printf("shuju.p13.pic=15\xff\xff\xff");
				huo=1;
			}
			if(gas==1)
			{
				printf("shuju.t11.txt=\"��\"\xff\xff\xff");
				printf("shuju.p11.pic=12\xff\xff\xff");
				ke=0;
			}
			else
			{
				printf("shuju.t11.txt=\"��\"\xff\xff\xff");
				printf("shuju.p11.pic=13\xff\xff\xff");
				ke=1;
			}
			if(temp>=set_temp)
				printf("shuju.p1.pic=3\xff\xff\xff");
			else
				printf("shuju.p1.pic=2\xff\xff\xff");
			if(humi>=set_humi)
				printf("shuju.p3.pic=5\xff\xff\xff");
			else
				printf("shuju.p3.pic=4\xff\xff\xff");
			if(tvoc>=set_tvoc)
				printf("shuju.p7.pic=9\xff\xff\xff");
			else
				printf("shuju.p7.pic=12\xff\xff\xff");
			if(co2>=set_co2)
				printf("shuju.p9.pic=11\xff\xff\xff");
			else
				printf("shuju.p9.pic=10\xff\xff\xff");
			if(pm25>=set_pm25)
				printf("shuju.p5.pic=7\xff\xff\xff");
			else
				printf("shuju.p5.pic=6\xff\xff\xff");
			printf("shuju.t3.txt=\"%.1f\"\xff\xff\xff",temp);
			printf("shuju.t4.txt=\"%.1f\"\xff\xff\xff",humi);
			printf("shuju.t5.txt=\"%d\"\xff\xff\xff",pm25);
			printf("shuju.t9.txt=\"%d\"\xff\xff\xff",co2);
			printf("shuju.t7.txt=\"%d\"\xff\xff\xff",tvoc);
			flag=0;
		}
		if(flame==0 || gas==0 || temp>=set_temp || humi>=set_humi || tvoc>=set_tvoc || co2>=set_co2 || pm25>=set_pm25)
			printf("play 0,1,0\xff\xff\xff");
		else 
			printf("audio0=0\xff\xff\xff");
		delay_ms(500);
		u3_printf("%c%c%c%c%c%c%c",(int)temp,(int)humi,(int)pm25,(int)co2,(int)tvoc,(int)ke,(int)huo);
	} 
}


